// LeetCode #34: Find First and Last Position of Element in Sorted Array
// Topic: Array
// Add the exact LeetCode method signature from the problem page before submission.
class Solution {
    // TODO: Implement Find First and Last Position of Element in Sorted Array
}

