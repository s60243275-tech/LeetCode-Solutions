class Solution { public int findNumbers(int[]a){int c=0;for(int x:a)if(String.valueOf(x).length()%2==0)c++;return c;} }
