class Solution { public int removeElement(int[] a,int val){int k=0;for(int x:a)if(x!=val)a[k++]=x;return k;} }
