import java.util.*;

class Solution { public int numIdenticalPairs(int[] a){java.util.Map<Integer,Integer>m=new java.util.HashMap<>();int r=0;for(int x:a){r+=m.getOrDefault(x,0);m.put(x,m.getOrDefault(x,0)+1);}return r;} }
