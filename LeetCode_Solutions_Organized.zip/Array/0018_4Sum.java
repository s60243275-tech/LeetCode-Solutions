// LeetCode #18: 4Sum
// Topic: Array
// Add the exact LeetCode method signature from the problem page before submission.
class Solution {
    // TODO: Implement 4Sum
}

