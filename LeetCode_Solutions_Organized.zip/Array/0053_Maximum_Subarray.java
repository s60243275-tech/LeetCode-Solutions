class Solution { public int maxSubArray(int[]a){int c=a[0],r=a[0];for(int i=1;i<a.length;i++){c=Math.max(a[i],c+a[i]);r=Math.max(r,c);}return r;} }
