class Solution { public int removeDuplicates(int[]a){int k=0;for(int x:a)if(k<2||x!=a[k-2])a[k++]=x;return k;} }
