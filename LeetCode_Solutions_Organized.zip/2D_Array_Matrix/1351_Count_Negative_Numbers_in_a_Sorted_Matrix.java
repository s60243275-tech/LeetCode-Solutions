class Solution { public int countNegatives(int[][] g){int r=g.length-1,c=0,ans=0;while(r>=0&&c<g[0].length){if(g[r][c]<0){ans+=g[0].length-c;r--;}else c++;}return ans;} }
