class Solution { public int maximumWealth(int[][] a){int r=0;for(int[]x:a){int s=0;for(int y:x)s+=y;r=Math.max(r,s);}return r;} }
