class Solution { public int diagonalSum(int[][] m){int n=m.length,s=0;for(int i=0;i<n;i++){s+=m[i][i];if(i!=n-1-i)s+=m[i][n-1-i];}return s;} }
