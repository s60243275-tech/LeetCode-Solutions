# LeetCode Solutions — Java

This ZIP contains the **unique problems** from the LeetCode list you provided, organized by topic.

## Folders
- `2D_Array_Matrix` — matrix and 2D-array problems
- `String` — string problems
- `Linked_List` — linked-list problems
- `Array` — array/two-pointer/greedy problems
- `Stack_Queue` — stack-related problems
- `Tree` — tree traversal
- `Backtracking` — recursion/backtracking problems
- `Dynamic_Programming` — DP problems
- `Binary_Search_Math` — binary-search and math problems
- `Other` — problems for which the exact method signature/solution was not safely inferred

## Important
- Each solution is stored as a separate `.java` file.
- Files use the LeetCode `Solution` class style.
- LeetCode already provides the `ListNode` and `TreeNode` definitions when required.
- Some complex/less-certain entries are marked `TODO` rather than pretending to be verified.
- Duplicate entries in your pasted history were included only once.

## Source
LeetCode problem titles/IDs were taken from the list you supplied.
