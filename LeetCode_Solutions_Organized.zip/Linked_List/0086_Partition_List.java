// LeetCode #86: Partition List
// Topic: Linked_List
// Add the exact LeetCode method signature from the problem page before submission.
class Solution {
    // TODO: Implement Partition List
}

