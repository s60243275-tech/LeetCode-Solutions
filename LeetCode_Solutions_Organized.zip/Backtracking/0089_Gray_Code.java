// LeetCode #89: Gray Code
// Topic: Backtracking
// Add the exact LeetCode method signature from the problem page before submission.
class Solution {
    // TODO: Implement Gray Code
}

