import java.util.*;

class Solution { public List<List<Integer>> subsets(int[] a){List<List<Integer>>r=new ArrayList<>();r.add(new ArrayList<>());for(int x:a){int n=r.size();for(int i=0;i<n;i++){List<Integer>p=new ArrayList<>(r.get(i));p.add(x);r.add(p);}}return r;} }
