import java.util.*;

class Solution { public List<List<Integer>> permute(int[] a){List<List<Integer>>r=new ArrayList<>();boolean[]u=new boolean[a.length];dfs(a,u,new ArrayList<>(),r);return r;}void dfs(int[]a,boolean[]u,List<Integer>p,List<List<Integer>>r){if(p.size()==a.length){r.add(new ArrayList<>(p));return;}for(int i=0;i<a.length;i++)if(!u[i]){u[i]=true;p.add(a[i]);dfs(a,u,p,r);p.remove(p.size()-1);u[i]=false;}} }
