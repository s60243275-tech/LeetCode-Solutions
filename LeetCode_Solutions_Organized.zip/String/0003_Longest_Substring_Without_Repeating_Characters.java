import java.util.*;

class Solution {
    public int lengthOfLongestSubstring(String s) {
        int[] last=new int[256]; java.util.Arrays.fill(last,-1); int l=0,ans=0;
        for(int r=0;r<s.length();r++){ char c=s.charAt(r); l=Math.max(l,last[c]+1); last[c]=r; ans=Math.max(ans,r-l+1); }
        return ans;
    }
}
