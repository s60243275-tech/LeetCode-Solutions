import java.util.*;

class Solution { public int romanToInt(String s){java.util.Map<Character,Integer>m=new java.util.HashMap<>();int[]v={1,5,10,50,100,500,1000};char[]c={'I','V','X','L','C','D','M'};for(int i=0;i<c.length;i++)m.put(c[i],v[i]);int a=0;for(int i=0;i<s.length();i++){int x=m.get(s.charAt(i));a+=i+1<s.length()&&x<m.get(s.charAt(i+1))?-x:x;}return a;} }
