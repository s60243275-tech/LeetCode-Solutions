// LeetCode #71: Simplify Path
// Topic: String
// Add the exact LeetCode method signature from the problem page before submission.
class Solution {
    // TODO: Implement Simplify Path
}

