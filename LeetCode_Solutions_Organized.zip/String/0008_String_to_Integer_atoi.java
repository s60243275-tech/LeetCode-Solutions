import java.util.*;

class Solution { public int myAtoi(String s){int i=0,n=s.length(),sign=1;long r=0;while(i<n&&s.charAt(i)==' ')i++;if(i<n&&(s.charAt(i)=='+'||s.charAt(i)=='-')){if(s.charAt(i++)=='-')sign=-1;}while(i<n&&Character.isDigit(s.charAt(i))){r=r*10+s.charAt(i++)-'0';if(sign*r>Integer.MAX_VALUE)return Integer.MAX_VALUE;if(sign*r<Integer.MIN_VALUE)return Integer.MIN_VALUE;}return(int)(sign*r);} }
