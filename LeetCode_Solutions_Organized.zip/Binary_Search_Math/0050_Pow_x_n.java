class Solution { public double myPow(double x,int n){long e=n;double r=1;while(e!=0){if((e&1)!=0)r*=x;x*=x;e>>=1;}return n<0?1/r:r;} }
